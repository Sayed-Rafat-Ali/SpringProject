package in.sp.dbcon;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnection {
		
	public static Connection getConnecton()
	{
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(
	                "jdbc:mysql://localhost:3306/mvc_db",
	                "root",                     // username
	                "#Rafat1410"                // password
	            );

			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return con;
	}
}
